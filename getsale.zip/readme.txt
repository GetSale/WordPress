=== getSale ===
Contributors: getSale Team
Tags: getsale, popup, popups
Requires at least: 3.0.1
Tested up to: 4.5.2
Stable tag: 1.0.0

== Description ==
getSale — профессиональный инструмент для создания popup-окон

В getSale реализованы следующие полезные опции:
* возможность выборочного показа pop-up виджета (скидки, спецпредложения) отдельным сегментам посетителей;

== Installation ==
1. Выберите Плагины -> Добавить новый.
2. В строке поиска введите getSale.
3. Установите плагин *getSale* и активируйте его.
4. Введите Еmail и полученный на сайте http://edge.getsale.io и Ключ API.

== Screenshots ==
1. Плагин getSale
2. Личный кабинет на сайте http://edge.getsale.io

== Changelog ==
= 1.0.0 =
* Релиз